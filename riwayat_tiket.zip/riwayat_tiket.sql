-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 30 Nov 2019 pada 01.41
-- Versi Server: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tiket_kai`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `riwayat_tiket`
--

CREATE TABLE IF NOT EXISTS `riwayat_tiket` (
  `kode_pemesanan` varchar(50) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `nama_kereta` varchar(255) NOT NULL,
  `kelas_kereta` varchar(50) NOT NULL,
  `tgl_keberangkatan` varchar(255) NOT NULL,
  `tgl_kedatangan` varchar(255) NOT NULL,
  `harga` int(50) NOT NULL,
  `ket` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `riwayat_tiket`
--

INSERT INTO `riwayat_tiket` (`kode_pemesanan`, `nama`, `nama_kereta`, `kelas_kereta`, `tgl_keberangkatan`, `tgl_kedatangan`, `harga`, `ket`) VALUES
('AGT50', 'Wino Rama Putra', 'Argo Wilis', 'Eksekutif', '10 Desember 2019', '11 Desember 2019', 500000, 'Lunas');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `riwayat_tiket`
--
ALTER TABLE `riwayat_tiket`
 ADD PRIMARY KEY (`kode_pemesanan`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
