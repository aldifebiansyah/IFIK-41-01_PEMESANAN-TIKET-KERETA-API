-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 02 Des 2019 pada 19.48
-- Versi Server: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tiket_kai`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal`
--

CREATE TABLE IF NOT EXISTS `jadwal` (
  `kode_pemesanan` varchar(15) NOT NULL,
  `nama_kereta` varchar(50) NOT NULL,
  `kota_asal` varchar(50) NOT NULL,
  `kota_tujuan` varchar(50) NOT NULL,
  `jam_keberangkatan` varchar(10) NOT NULL,
  `tgl_keberangkatan` varchar(20) NOT NULL,
  `kelas_kereta` varchar(15) NOT NULL,
  `harga` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `registrasi`
--

CREATE TABLE IF NOT EXISTS `registrasi` (
  `nik` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `registrasi`
--

INSERT INTO `registrasi` (`nik`, `nama`, `email`, `alamat`, `password`) VALUES
('', '', 'poncoe@gmail.com', '', '1331331'),
('1234567890', 'Ini Budi', 'budi@ini.com', 'madiun', '123456'),
('351901150598 0002', 'ZakiZar', 'zakigaming.zar@gmail.com', 'kebonsari, madiun, jawa timur', ''),
('3519011505980002', 'Zakiya Ainur Rohman', 'zakigaming.zar@gmail.com', 'kebonsari, madiun, jawa timur', '123456');

-- --------------------------------------------------------

--
-- Struktur dari tabel `riwayat_tiket`
--

CREATE TABLE IF NOT EXISTS `riwayat_tiket` (
  `kode_pemesanan` varchar(15) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `nama_kereta` varchar(50) NOT NULL,
  `kota_asal` varchar(50) NOT NULL,
  `kota_tujuan` varchar(50) NOT NULL,
  `jam_keberangkatan` varchar(10) NOT NULL,
  `tgl_keberangkatan` varchar(20) NOT NULL,
  `kelas_kereta` varchar(15) NOT NULL,
  `harga` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `riwayat_tiket`
--

INSERT INTO `riwayat_tiket` (`kode_pemesanan`, `nama`, `nama_kereta`, `kota_asal`, `kota_tujuan`, `jam_keberangkatan`, `tgl_keberangkatan`, `kelas_kereta`, `harga`) VALUES
('ASB76', 'Zar', 'Kahuripan', 'Ekonomi', '12 Desember 2019', '13 Desembe', '84000', 'Belum Lunas', ''),
('BG78H', 'Aldi', 'Malabar', 'Bisnis', '7 Desember 2019', '8 Desember', '400000', 'Lunas', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jadwal`
--
ALTER TABLE `jadwal`
 ADD PRIMARY KEY (`kode_pemesanan`);

--
-- Indexes for table `registrasi`
--
ALTER TABLE `registrasi`
 ADD PRIMARY KEY (`nik`);

--
-- Indexes for table `riwayat_tiket`
--
ALTER TABLE `riwayat_tiket`
 ADD PRIMARY KEY (`kode_pemesanan`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
